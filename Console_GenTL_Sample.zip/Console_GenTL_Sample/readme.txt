This project files is GPL licesne.
You can use free of charge.

This program opens and displays the cti file located in GENICAM_GENTL64_PATH.
Displays from the vendor name to the URL PATH.


March 30th. 2022
Euresys Japan K.K.
Kazuhiro Tanaka

e-Mail:kazuhiro.tanaka@euresys.com