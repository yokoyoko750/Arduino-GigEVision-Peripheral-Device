﻿// Console_GenTL_Sample.cpp : このファイルには 'main' 関数が含まれています。プログラム実行の開始と終了がそこで行われます。
//

#include <iostream>
#include "GenTL.h"
#include "Console_GenTL_Sample.h"

const char *ENV_VAR = "GENICAM_GENTL64_PATH";

void check_address()
{
	std::cout << "***** Check_Address *****\n";
	// Get Address
	m_pGCInitLib = reinterpret_cast<PGCInitLib>(GetProcAddress(m_hDll, "GCInitLib"));
	if (m_pGCInitLib == NULL)
		std::cout << "Failed to Get GCInitLib\n";

	m_pGCCloseLib = reinterpret_cast<PGCCloseLib>(GetProcAddress(m_hDll, "GCCloseLib"));
	if (m_pGCCloseLib == NULL)
		std::cout << "Failed to Get GCCloseLib\n";

	m_pTLOpen = reinterpret_cast<PTLOpen>(GetProcAddress(m_hDll, "TLOpen"));
	if (m_pTLOpen == NULL)
		std::cout << "Failed to Get TLOpen\n";

	m_pTLClose = reinterpret_cast<PTLClose>(GetProcAddress(m_hDll, "TLClose"));
	if (m_pTLClose == NULL)
		std::cout << "Failed to Get TLClose\n";

	m_pTLGetInfo = reinterpret_cast<PTLGetInfo>(GetProcAddress(m_hDll, "TLGetInfo"));
	if (m_pTLGetInfo == NULL)
		std::cout << "Failed to Get TLGetInfo\n";

	m_pTLUpdateInterfaceList = reinterpret_cast<PTLUpdateInterfaceList>(GetProcAddress(m_hDll, "TLUpdateInterfaceList"));
	if (m_pTLUpdateInterfaceList == NULL)
		std::cout << "Failed to Get TLUpdateInterfaceList\n";

	m_pTLGetNumInterfaces = reinterpret_cast<PTLGetNumInterfaces>(GetProcAddress(m_hDll, "TLGetNumInterfaces"));
	if (m_pTLGetNumInterfaces == NULL)
		std::cout << "Failed to Get TLGetNumInterfaces\n";

	m_pTLGetInterfaceID = reinterpret_cast<PTLGetInterfaceID>(GetProcAddress(m_hDll, "TLGetInterfaceID"));
	if (m_pTLGetInterfaceID == NULL)
		std::cout << "Failed to Get TLGetInterfaceID\n";

	m_pTLGetInterfaceInfo = reinterpret_cast<PTLGetInterfaceInfo>(GetProcAddress(m_hDll, "TLGetInterfaceInfo"));
	if (m_pTLGetInterfaceInfo == NULL)
		std::cout << "Failed to Get TLGetInterfaceInfo\n";

	m_pTLOpenInterface = reinterpret_cast<PTLOpenInterface>(GetProcAddress(m_hDll, "TLOpenInterface"));
	if (m_pTLOpenInterface == NULL)
		std::cout << "Failed to Get TLOpenInterface\n";

	m_pIFUpdateDeviceList = reinterpret_cast<PIFUpdateDeviceList>(GetProcAddress(m_hDll, "IFUpdateDeviceList"));
	if (m_pIFUpdateDeviceList == NULL)
		std::cout << "Failed to Get IFUpdateDeviceList\n";

	m_pIFGetInfo = reinterpret_cast<PIFGetInfo>(GetProcAddress(m_hDll, "IFGetInfo"));
	if (m_pIFGetInfo == NULL)
		std::cout << "Failed to Get IFGetInfo\n";

	m_pIFGetNumDevices = reinterpret_cast<PIFGetNumDevices>(GetProcAddress(m_hDll, "IFGetNumDevices"));
	if (m_pIFGetNumDevices == NULL)
		std::cout << "Failed to Get IFGetNumDevices\n";

	m_pIFGetDeviceID = reinterpret_cast<PIFGetDeviceID>(GetProcAddress(m_hDll, "IFGetDeviceID"));
	if (m_pIFGetDeviceID == NULL)
		std::cout << "Failed to Get IFGetDeviceID\n";

	m_pIFOpenDevice = reinterpret_cast<PIFOpenDevice>(GetProcAddress(m_hDll, "IFOpenDevice"));
	if (m_pIFOpenDevice == NULL)
		std::cout << "Failed to Get IFOpenDevice\n";

	m_pIFClose = reinterpret_cast<PIFClose>(GetProcAddress(m_hDll, "IFClose"));
	if (m_pIFClose == NULL)
		std::cout << "Failed to Get IFClose\n";

	m_pDevGetPort = reinterpret_cast<PDevGetPort>(GetProcAddress(m_hDll, "DevGetPort"));
	if (m_pDevGetPort == NULL)
		std::cout << "Failed to Get DevGetPort\n";

	m_pDevClose = reinterpret_cast<PDevClose>(GetProcAddress(m_hDll, "DevClose"));
	if (m_pDevGetPort == NULL)
		std::cout << "Failed to Get DevClose\n";

	m_pDevGetInfo = reinterpret_cast<PDevGetInfo>(GetProcAddress(m_hDll, "DevGetInfo"));
	if (m_pDevGetPort == NULL)
		std::cout << "Failed to Get DevGetInfo\n";

	m_pGCGetNumPortURLs = reinterpret_cast<PGCGetNumPortURLs>(GetProcAddress(m_hDll, "GCGetNumPortURLs"));
	if (m_pDevGetPort == NULL)
		std::cout << "Failed to Get GCGetNumPortURLs\n";

	m_pGCGetPortURLInfo = reinterpret_cast<PGCGetPortURLInfo>(GetProcAddress(m_hDll, "GCGetPortURLInfo"));
	if (m_pDevGetPort == NULL)
		std::cout << "Failed to Get GCGetPortURLInfo\n";
}

CStringA get_environment_variable(const char* environment_name) {
	size_t buf;
	char buffer[1024];
	if (getenv_s(&buf, buffer, 1024, environment_name)) throw std::runtime_error("read error");
	if (buf == 0) throw std::runtime_error("not such environment variable");
	return CStringA(buffer);
}

bool Select_cti_file()
{
	CStringA gPath = get_environment_variable(ENV_VAR);
	std::cout << "GENICAM_GENTL64_PATH = " << gPath << "\n";

	HANDLE hFind;
	WIN32_FIND_DATA win32fd;
	CStringA file_names[16];
	// finding only extention cti
	CStringA extention = "cti";

	CStringA search_name = gPath + "\\*." + extention;
	hFind = FindFirstFileW((CString)search_name, &win32fd);
	if (hFind == INVALID_HANDLE_VALUE) {
		std::cout << "GENICAM_GENTL64_PATH : " << gPath << " is empty. \n";
		return false;
	}
	int cunt = 0;
	do {
		if (win32fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
		}
		else {
			file_names[cunt++] = (win32fd.cFileName);
		}
	} while (FindNextFile(hFind, &win32fd));

	filepath = gPath + "\\" + file_names[0];
	std::cout << "Found cti file : " + file_names[0] + "\n";

//  filepath = "C:\\Program Files\\Euresys\\eGrabber\\cti\\x86_64\\coaxlink.cti";
//	filepath = "C:\\Program Files\\Euresys\\eGrabber\\cti\\x86_64\\gigelink.cti";

	return true;
}

GC_ERROR TLOpen()
{
	m_hTL = NULL;
	std::cout << "***** TL Open *****\n";
	// InitLib
	GC_ERROR nResult = m_pGCInitLib();
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : GCInitLib\n";
		return nResult;
	}

	// TLOpen
	nResult = m_pTLOpen(&m_hTL);
	if (nResult != GC_ERR_SUCCESS || m_hTL == NULL)
	{
		std::cout << "Error : TLOpen\n";
		return nResult;
	}
	// Get Information
	char cdata[128];
	size_t stSize = sizeof(cdata);
	INFO_DATATYPE iType = INFO_DATATYPE_STRING;

	//   TL_INFO_ID
	// GC_API_P(PTLGetInfo)(TL_HANDLE hTL, TL_INFO_CMD iInfoCmd, INFO_DATATYPE *piType, void *pBuffer, size_t *piSize );
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_ID, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLGetInfo TL_INFO_ID\n";
		return nResult;
	}
	std::cout << "*** TL_INFO_ID = " + (CStringA)cdata + "\n";


	//   TL_INFO_VENDOR
	stSize = 32;
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_VENDOR, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLGetInfo TL_INFO_VENDOR\n";
		return nResult;
	}
	std::cout << "*** TL_INFO_VENDOR = " + (CStringA)cdata + "\n";


	//   TL_INFO_MODEL
	stSize = 32;
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_MODEL, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLGetInfo TL_INFO_MODEL\n";
		return nResult;
	}
	std::cout << "*** TL_INFO_MODEL = " + (CStringA)cdata + "\n";

	//   TL_INFO_VERSION
	stSize = 32;
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_VERSION, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLGetInfo TL_INFO_VERSION\n";
		return nResult;
	}
	std::cout << "*** TL_INFO_VERSION = " + (CStringA)cdata + "\n";

	//   TL_INFO_TLTYPE
	stSize = 48;
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_TLTYPE, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLGetInfo TL_INFO_TLTYPE\n";
		return nResult;
	}
	std::cout << "*** TL_INFO_TLTYPE = " + (CStringA)cdata + "\n";

	//   TL_INFO_NAME
	stSize = 16;	// cti file name getting from cti file.
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_NAME, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLGetInfo TL_INFO_NAME\n";
		return nResult;
	}
	std::cout << "*** TL_INFO_NAME = " + (CStringA)cdata + "\n";

	//   TL_INFO_PATHNAME
	stSize = 128;
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_PATHNAME, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
		std::cout << "Error : TLGetInfo TL_INFO_PATHNAME\n";
	else
		std::cout << "*** TL_INFO_PATHNAME = " + (CStringA)cdata + "\n";

	//   TL_INFO_DISPLAYNAME
	stSize = 64;
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_DISPLAYNAME, &iType, cdata, &stSize);
	if (nResult != GC_ERR_SUCCESS)
		std::cout << "Error : TLGetInfo TL_INFO_DISPLAYNAME\n";
	else
		std::cout << "*** TL_INFO_DISPLAYNAME = " + (CStringA)cdata + "\n";

	//   TL_INFO_CHAR_ENCODNIG
	iType = INFO_DATATYPE_INT32;
	int32_t iData;
	stSize = sizeof(iData);
	CString s;
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_CHAR_ENCODING, &iType, &iData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
		std::cout << "Error : TLGetInfo TL_INFO_CHAR_ENCODNIG\n";
	else
	{
		s.Format(_T("*** TL_INFO_CHAR_ENCODNIG = %d \n"), iData);
		std::cout << (CStringA)s;
	}
	//   TL_INFO_GENTL_VER_MAJOR
	iType = INFO_DATATYPE_UINT32;
	uint32_t uData;
	stSize = sizeof(uData);
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_GENTL_VER_MAJOR, &iType, &uData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
		std::cout << "Error : TLGetInfo TL_INFO_GENTL_VER_MAJOR\n";
	else
	{
		s.Format(_T("*** TL_INFO_GENTL_VER_MAJOR = %d \n"), uData);
		std::cout << (CStringA)s;
	}
	//   TL_INFO_GENTL_VER_MINOR
	stSize = sizeof(uData);
	nResult = m_pTLGetInfo(m_hTL, TL_INFO_GENTL_VER_MINOR, &iType, &uData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
		std::cout << "Error : TLGetInfo TL_INFO_GENTL_VER_MINOR\n";
	else
	{
		s.Format(_T("*** TL_INFO_GENTL_VER_MINOR = %d \n"), uData);
		std::cout << (CStringA)s;
	}
	return GC_ERR_SUCCESS;
}

GC_ERROR DeviceCheck()
{
	m_hIF = NULL;			// Interface Handle
	m_hDEV = NULL;			// Device Handle

	CString s;

	std::cout << "***** Device Check *****\n";

	// Updates interface list
	GC_ERROR nResult = m_pTLUpdateInterfaceList(m_hTL, false, 1000);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLUpdateInterfaceList\n";
		return nResult;
	}

	// Get NumberOfInterface
	nResult = m_pTLGetNumInterfaces(m_hTL, &m_iNumOfInterfaces);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : TLGetNumInterfaces\n";
		return nResult;
	}
	s.Format(_T("*** %d Interfaces found \n"), m_iNumOfInterfaces);
	std::cout << (CStringA)s;

	// Get first InterfaceID
	char		cIfName[256];
	size_t		stSize = sizeof(cIfName);
	// GC_API TLGetInterfaceID(TL_HANDLE hTL, uint32_t iIndex, char *sID, size_t *piSize);
	nResult = m_pTLGetInterfaceID(m_hTL, 0, cIfName, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : TLGetInterfaceID Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "TLGetInterfaceID Sucessed by InterfaceID = 0\n";

	// Open first interface
	nResult = m_pTLOpenInterface(m_hTL, cIfName, &m_hIF);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : TLOpenInterface Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "TLOpenInterface Sucessed by InterfaceID = 0\n";

	// Get Information
	INFO_DATATYPE iType = INFO_DATATYPE_STRING;
	char cdData[255];
	stSize = sizeof(cdData);

	//   INTERFACE_INFO_ID
	nResult = m_pIFGetInfo(m_hIF, INTERFACE_INFO_ID, &iType, cdData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : IFGetInfo INTERFACE_INFO_ID\n";
		return nResult;
	}
	std::cout << "*** INTERFACE_INFO_ID = " + (CStringA)cdData + "\n";

	//   INTERFACE_INFO_DISPLAY_NAME
	char ifData[512];
	stSize = sizeof(ifData);
	nResult = m_pIFGetInfo(m_hIF, INTERFACE_INFO_DISPLAYNAME, &iType, ifData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : IFGetInfo INTERFACE_INFO_DISPLAYNAME\n";
		return nResult;
	}
	std::cout << "*** INTERFACE_INFO_DISPLAYNAME = " + (CStringA)ifData + "\n";

	//   INTERFACE_INFO_TLTYPE
	char itData[16];
	stSize = sizeof(itData);
	nResult = m_pIFGetInfo(m_hIF, INTERFACE_INFO_TLTYPE, &iType, itData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : IFGetInfo INTERFACE_INFO_TLTYPE\n";
		return nResult;
	}
	std::cout << "*** INTERFACE_INFO_TLTYPE = " + (CStringA)itData + "\n";

	// Update DeviceList
	nResult = m_pIFUpdateDeviceList(m_hIF, false, 5000);
	if (nResult != GC_ERR_SUCCESS)
	{
		std::cout << "Error : IFUpdateDeviceList\n";
		return nResult;
	}

	// Get NumberOfDevices
	nResult = m_pIFGetNumDevices(m_hIF, &m_iNumOfDevices);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : IFGetNumDevices Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	s.Format(_T("*** %d Devices found \n"), m_iNumOfDevices);
	std::cout << (CStringA)s;

	stSize = 255;
	// Get DeviceID
	// GC_API IFGetDeviceID(IF_HANDLE hIface, uint32_t iIndex, char *sIDeviceID, size_t *piSize);
	nResult = m_pIFGetDeviceID(m_hIF, 0, m_cDeviceID, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : IFGetDeviceID Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "*** DeviceID = " + (CStringA)m_cDeviceID + "\n";

	// Open Device

	// GC_API IFOpenDevice( IF_HANDLE hIface, const char *sDeviceID, DEVICE_ACCESS_FLAGS iOpenFlag, DEV_HANDLE *phDevice );
	nResult = m_pIFOpenDevice(m_hIF, m_cDeviceID, DEVICE_ACCESS_CONTROL, &m_hDEV);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : IFPoenDevice Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "OpenDevice Sucessed by DeviceID = " + (CStringA)m_cDeviceID + "\n";

	// Get Device port
	// GC_API_P(PDevGetPort)(DEV_HANDLE hDevice, PORT_HANDLE *phRemoteDevice);
	nResult = m_pDevGetPort(m_hDEV, &m_hPORT);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : DevGetPort Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "Getting Device Port Sucessed by DeviceID = " + (CStringA)m_cDeviceID + "\n";

	// Get Device Vendor
	char VenData[32];	// GigE Vision specification is 32 words.
	stSize = sizeof(VenData);
	//GC_API_P(PDevGetInfo)(DEV_HANDLE hDevice, DEVICE_INFO_CMD iInfoCmd, INFO_DATATYPE *piType, void *pBuffer, size_t *piSize);
	nResult = m_pDevGetInfo(m_hDEV, DEVICE_INFO_VENDOR, &iType, VenData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : PDevGetInfo Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "*** Device Vendor ID = " + (CStringA)VenData + "\n";

	char modData[32];
	stSize = sizeof(modData);
	//GC_API_P(PDevGetInfo)(DEV_HANDLE hDevice, DEVICE_INFO_CMD iInfoCmd, INFO_DATATYPE *piType, void *pBuffer, size_t *piSize);
	nResult = m_pDevGetInfo(m_hDEV, TL_INFO_MODEL, &iType, modData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : PDevGetInfo Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "*** Device Model Name = " + (CStringA)modData + "\n";

	// Get Number of URLs
	uint32_t iUrlNum = 0;
	// GC_API_P(PGCGetNumPortURLs)(PORT_HANDLE hPort, uint32_t *iNumURLs);
	nResult = m_pGCGetNumPortURLs(m_hPORT, &iUrlNum);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : GCGetNumPortURLs Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	s.Format(_T("Total URL Port is %d \n"), iUrlNum);
	std::cout << (CStringA)s;

	// Reading first URL
	char urlData[256];
	stSize = sizeof(urlData);
	// GC_API GCGetPortURLInfo(PORT_HANDLE hPort, uint32_t iURLIndex, URL_INFO_CMD iInfoCmd, INFO_DATATYPE *piType, void *pBuffer, size_t *piSize);
	nResult = m_pGCGetPortURLInfo(m_hPORT, 0, URL_INFO_URL, &iType, urlData, &stSize);
	if (nResult != GC_ERR_SUCCESS)
	{
		s.Format(_T("Error : GCGetPortURLInfo Code %d \n"), nResult);
		std::cout << (CStringA)s;
		return nResult;
	}
	std::cout << "*** URL = " + (CStringA)urlData + "\n";

	return GC_ERR_SUCCESS;
}

int main()
{
	std::cout << "GenTL Sample Start!\n";

	if (Select_cti_file())
	{
		m_hDll = LoadLibrary(filepath);
		if (m_hDll == NULL)
		{
			std::cout << "Failed to Load .cti file\n";
		}
		else
		{
			check_address();
			if (TLOpen() == GC_ERR_SUCCESS)
			{
				GC_ERROR Dev_error = DeviceCheck();
			}
		}
	}
	std::cout << "GenTL Sample End!\n";
}

