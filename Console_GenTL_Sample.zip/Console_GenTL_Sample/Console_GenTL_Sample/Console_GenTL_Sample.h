#pragma once
#include <afx.h>

#include "GenTL.h"
using namespace GenTL;

CString						filepath;
HMODULE						m_hDll;							// .cti�t�@�C��
TL_HANDLE					m_hTL;							// TransportLayer Handle
IF_HANDLE					m_hIF;							// Interface Handle
DEV_HANDLE					m_hDEV;							// Device Handle
PORT_HANDLE					m_hPORT;						// Port Gandle

uint32_t					m_iNumOfInterfaces;				// �C���^�[�t�F�C�X��
uint32_t					m_iNumOfDevices;				// �f�o�C�X��
char						m_cDeviceID[256];				// �f�o�C�XID
char						m_cVendorName[32];				// �x���_�[��
char						m_cCameraName[32];				// �J������
char						m_cCameraSerial[16];			// �J�����V���A��

PGCInitLib					m_pGCInitLib;
PGCCloseLib					m_pGCCloseLib;

PTLOpen						m_pTLOpen;
PTLClose					m_pTLClose;
PTLGetInfo					m_pTLGetInfo;
PTLUpdateInterfaceList		m_pTLUpdateInterfaceList;
PTLGetNumInterfaces			m_pTLGetNumInterfaces;
PTLGetInterfaceID			m_pTLGetInterfaceID;
PTLGetInterfaceInfo			m_pTLGetInterfaceInfo;
PTLOpenInterface			m_pTLOpenInterface;

PIFUpdateDeviceList			m_pIFUpdateDeviceList;
PIFGetInfo					m_pIFGetInfo;
PIFGetNumDevices			m_pIFGetNumDevices;
PIFGetDeviceID				m_pIFGetDeviceID;
PIFOpenDevice				m_pIFOpenDevice;
PIFClose					m_pIFClose;

PDevGetPort					m_pDevGetPort;
PDevGetNumDataStreams		m_pDevGetNumDataStreams;
PDevGetDataStreamID			m_pDevGetDataStreamID;
PDevOpenDataStream			m_pDevOpenDataStream;
PDevGetInfo					m_pDevGetInfo;
PDevClose					m_pDevClose;

PDSAnnounceBuffer			m_pDSAnnounceBuffer;
PDSAllocAndAnnounceBuffer	m_pDSAllocAndAnnounceBuffer;
PDSFlushQueue				m_pDSFlushQueue;
PDSStartAcquisition			m_pDSStartAcquisition;
PDSStopAcquisition			m_pDSStopAcquisition;
PDSGetInfo					m_pDSGetInfo;
PDSGetBufferID				m_pDSGetBufferID;
PDSClose					m_pDSClose;
PDSRevokeBuffer				m_pDSRevokeBuffer;
PDSQueueBuffer				m_pDSQueueBuffer;
PDSGetBufferInfo			m_pDSGetBufferInfo;

/* GenTL v1.1 */
PGCGetNumPortURLs			m_pGCGetNumPortURLs;
PGCGetPortURLInfo			m_pGCGetPortURLInfo;
PGCReadPortStacked			m_pGCReadPortStacked;
PGCWritePortStacked			m_pGCWritePortStacked;

/* typedefs for dynamic loading */
PGCGetLastError				m_pGCGetLastError;