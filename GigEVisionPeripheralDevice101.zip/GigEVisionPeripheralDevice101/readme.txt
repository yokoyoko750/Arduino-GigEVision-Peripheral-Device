Released September 24, 2021 Device Version 1.01
The second stage of the set distributed at the JIIA Lighting Subcommittee

JIIA is Japan Industrial Imaging Comitte.
http://jiia.org/


The target device is
1．Arduino MEGA 2560 + Arduino Ethernet Shield 2 (W5500)
2．Arduino MEGA 2560 + Arduino Ethernet Shield   (W5100)

The second combination is cheap but currently doesn't work with LLA and
For advanced users as there is no guarantee that it will work even if the library is remade in the future

Arduino standard Ethernet Library does not support LLA.
If you want to connect by Peer to Peer, set the NIC to 192.168.xxx.xxx (Class C) and use it.
169.254.xxx.xxx may not be recognized by the standard W5100 or W5500 driver.
In that case, comment out all the LLA description in the Arduino source code and Forcibly set it to Persistent IP.

Device Version 1.01 Update information
1. The value of Persistent IP read by READREG was incorrect
2. Where the Request ID of Discovery ACK was fixed at 0x0001
   Changed to correspond to the Requst ID of Discovery Command




--------- Japanese --------------

2021年09月24日リリース Device Version 1.01
JIIA (一般社団法人日本インダストリアルイメージング協会) の照明分科会にて配布するセット 第2段目


ターゲットデバイスは
1．Arduino MEGA 2560 + Arduino Ethernet Shield 2 (W5500)
2．Arduino MEGA 2560 + Arduino Ethernet Shield   (W5100)


2番目の組み合わせは安いが現状LLAで動作しないし、
将来的にライブラリを作り変えても動く保証がないため上級者向け


Arduino標準のEthernet LibraryがLLAに対応していません。
Peer to Peerで接続したい場合はNICを192.168.xxx.xxx(Class C)に設定して使ってください。
169.254.xxx.xxxではW5100やW5500の標準ドライバが認識しない場合があります。
その場合はArduinoのソースコードでLLAの記述をすべてコメントアウトし、
強制的にPersistent IPになるように設定してください。


Device Version 1.01更新情報
1. READREGで読まれるPersistent IPの値が間違っていた
2. Discovery ACKのRequest IDを0x0001に決め打ちしていたところを
　 Discovery CommandのRequst IDに対応するように変更
