EM-100GE_Ver000.xml	ひな形
EM-100GE_Ver002.xml	Ver0.01を元にIP Addressレジスタに<Representation>HexNumber</Representation>を加えた

