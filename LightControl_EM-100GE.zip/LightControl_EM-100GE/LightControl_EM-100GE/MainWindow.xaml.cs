﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LightControl_EM_100GE
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        const int LightController0 = 0;
        const int LightController1 = 1;
        const int LightController2 = 2;
        const int LightController3 = 3;

        SphinxLib.DISCOVERY disc;
        SphinxLib.CONNECTION con;
        string errorStr;
        byte device = 0;
        //      byte maxLevel;
        const string TargetModel = "EM-100GE";
        ushort error;

        public MainWindow()
        {
            InitializeComponent();

            if (!discovery())
                return;

            // set CONNECTION parameter for GEVInit function
            con.AdapterIP = disc.param[device].AdapterIP;                 // network adapter ip address
            con.AdapterMask = disc.param[device].AdapterMask;             // network  adapter mask  
            con.IP_CANCam = disc.param[device].IP;                        // device ip address
            con.PortCtrl = 49149;                                         // set 0 to port than automatic port is use
            con.PortData = 49150;                                         // set 0 to port than automatic port is use

            // name of network adapter
            con.adapter_name = new char[disc.param[device].adapter_name.Length];
            Array.Copy(disc.param[device].adapter_name, con.adapter_name, disc.param[device].adapter_name.Length);

            SphinxLib.CallbackError call_error = new SphinxLib.CallbackError(CallbackErr);
            // init GigE device
            // error_callback_func, this function gets information, warning and error strings from SphinxLib 
            error = SphinxLib.GEVInit(device, ref con, call_error, 0, SphinxLib.EXCLUSIVE_ACCESS);
            if (error != SphinxLib.GEV_STATUS_SUCCESS)
            {
                SphinxLib.GetErrorString(device, error, out errorStr);
                Console.WriteLine("[ERROR] - GEVInit[" + errorStr + "]");
                return;
            }

            // init xml parser
            error = SphinxLib.GEVInitXml(device);
            if (error != SphinxLib.GEV_STATUS_SUCCESS)
            {
                SphinxLib.GetErrorString(device, error, out errorStr);
                Console.WriteLine("[ERROR] - GEVInitXml[" + errorStr + "]");
                return;
            }

            // Set LightControllerSelector to LightController0
            double dw64 = 0;
            dw64 = load_Light_Value(LightController0);
            Slider_LightLevel0.Value = dw64;
            Text_LigthtValue0.Text = dw64.ToString("F2") + "%";
            dw64 = load_Light_Value(LightController1);
            Slider_LightLevel1.Value = dw64;
            Text_LigthtValue1.Text = dw64.ToString("F2") + "%";
            dw64 = load_Light_Value(LightController2);
            Slider_LightLevel2.Value = dw64;
            Text_LigthtValue2.Text = dw64.ToString("F2") + "%";
            dw64 = load_Light_Value(LightController3);
            Slider_LightLevel3.Value = dw64;
            Text_LigthtValue3.Text = dw64.ToString("F2") + "%";
        }

        private bool discovery()
        {
            // discovery devices
            SphinxLib.GEVDiscovery(out disc, null, 400, false);

            // if no device found exit application
            if (disc.Count == 0)
            {
                Console.WriteLine("No GigE Device found");
                return false;
            }

            device = 99;
            // print out device info of found devices
            for (int i = 0; i < disc.Count; i++)
            {
                System.Text.ASCIIEncoding enc = new System.Text.ASCIIEncoding();

                String temp = enc.GetString(disc.param[i].model);

                if (0 <= temp.IndexOf(TargetModel))
                {
                    device = (byte)i;
                }

            }
            if (device == 99)
            {
                Console.WriteLine("No GigE Device found");
                return false;
            }

            UInt32 IpAddress = disc.param[device].AdapterIP;
            int mbyte3 = (int)((IpAddress & 0xff000000) >> 24);
            int mbyte2 = (int)((IpAddress & 0x00ff0000) >> 16);
            int mbyte1 = (int)((IpAddress & 0x0000ff00) >> 8);
            int mbyte0 = (int)(IpAddress & 0x000000ff);
            StatusIPAddress.Text = mbyte0.ToString() + "." + mbyte1.ToString() + "." + mbyte2.ToString() + "." + mbyte3.ToString();

            UInt32 SubnetMask = disc.param[device].AdapterMask;
            mbyte3 = (int)((SubnetMask & 0xff000000) >> 24);
            mbyte2 = (int)((SubnetMask & 0x00ff0000) >> 16);
            mbyte1 = (int)((SubnetMask & 0x0000ff00) >> 8);
            mbyte0 = (int)(SubnetMask & 0x000000ff);
            StatusSubnetMask.Text = mbyte0.ToString() + "." + mbyte1.ToString() + "." + mbyte2.ToString() + "." + mbyte3.ToString();

            String sDeviceManufacture = null;
            byte[] bDeviceManufacture = disc.param[device].manuf;
            uint j = 0;
            while (bDeviceManufacture[j] != 0x00)
                sDeviceManufacture = sDeviceManufacture + (char)bDeviceManufacture[j++];
            StatusDeviceVender.Text = sDeviceManufacture;

            String sDeviceModel = null;
            byte[] bDeviceModel = disc.param[device].model;
            uint k = 0;
            while (bDeviceModel[k] != 0x00)
                sDeviceModel = sDeviceModel + (char)bDeviceModel[k++];
            StatusDeviceModel.Text = sDeviceModel;
            return true;
        }

        private long load_Light_Value(int sLightSelector)
        {
            long ret_value = 0;

            // Set LightControllerSelector to LightController0
            error = SphinxLib.GEVSetFeatureInteger(device, "LightControllerSelector", sLightSelector);
            if (error != SphinxLib.GEV_STATUS_SUCCESS)
            {
                SphinxLib.GetErrorString(device, error, out errorStr);
                Console.WriteLine("[ERROR] - GEVInitXml[" + errorStr + "]");
                return 0;
            }
            // Set LightControllerSelector to LightController0
            // error = SphinxLib.GEVGetFeatureFloat(device, "LightBrightness", out ret_value);
            error = SphinxLib.GEVGetFeatureInteger(device, "LightBrightnessRaw", out ret_value);
            if (error != SphinxLib.GEV_STATUS_SUCCESS)
            {
                SphinxLib.GetErrorString(device, error, out errorStr);
                Console.WriteLine("[ERROR] - GEVInitXml[" + errorStr + "]");
                return 0;
            }
            return ret_value / 255 * 100;
        }

        private bool Set_Light_Value(int sLightSelector, double sValue)
        {
            // Set LightControllerSelector to LightController0
            error = SphinxLib.GEVSetFeatureInteger(device, "LightControllerSelector", sLightSelector);
            if (error != SphinxLib.GEV_STATUS_SUCCESS)
            {
                SphinxLib.GetErrorString(device, error, out errorStr);
                Console.WriteLine("[ERROR] - GEVInitXml[" + errorStr + "]");
                return false;
            }
            // Set LightControllerSelector to LightController0
            error = SphinxLib.GEVSetFeatureFloat(device, "LightBrightness", sValue);
            if (error != SphinxLib.GEV_STATUS_SUCCESS)
            {
                SphinxLib.GetErrorString(device, error, out errorStr);
                Console.WriteLine("[ERROR] - GEVInitXml[" + errorStr + "]");
                return false;
            }
            return true;
        }

        static void CallbackErr(byte cam_nr, IntPtr error_str)
        {
            // string l_str = Marshal.PtrToStringAnsi(error_str);
            //   Console.WriteLine(l_str);
        }

        private void Slider_LightLevel0_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double sValue = Slider_LightLevel0.Value;
            Set_Light_Value(LightController0, sValue);
            Text_LigthtValue0.Text = sValue.ToString("F2") + "%";
        }

        private void Slider_LightLevel1_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double sValue = Slider_LightLevel1.Value;
            Set_Light_Value(LightController1, sValue);
            Text_LigthtValue1.Text = sValue.ToString("F2") + "%";
        }

        private void Slider_LightLevel2_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double sValue = Slider_LightLevel2.Value;
            Set_Light_Value(LightController2, sValue);
            Text_LigthtValue2.Text = sValue.ToString("F2") + "%";
        }

        private void Slider_LightLevel3_ValueChanged(object sender, RoutedPropertyChangedEventArgs<double> e)
        {
            double sValue = Slider_LightLevel3.Value;
            Set_Light_Value(LightController3, sValue);
            Text_LigthtValue3.Text = sValue.ToString("F2") + "%";
        }
    }
}
