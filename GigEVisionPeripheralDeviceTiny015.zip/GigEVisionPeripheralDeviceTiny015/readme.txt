Tiny version
It also works with Arduino Leonardo + Ethernet Shield 2 or Arduino Leonardo ETH.

Limitation of Tiny Version from Base of Arduino MEGA2560
1. Does not support Persistent IP
2. Network Interface Configuration is fixed at 0x06 (DHCP only)
3. Only one LED (Version 1.05 only)

V1.00 Make a minimum set to start based from Arduino MEGA2560 code.
V1.01 Try returning 4 LEDs to the same four as MEGA2560
V1.02 Try inserting PersistentIP Adress
V1.03 Return to 1,01 and try entering USer Define Name (Read Only)
V1.04 Try deleting DISCOVERY_BUFF
V1.05 Return to 1.00 and enable ReadWrite of USer Define Name.

-------------- Japanese ----------

Tiny版
Arduino Leonardo + Ethernet Shield 2もしくはArduino Leonardo ETHでも動作する。

Arduino MEGA2560対応版に対する制限事項
1. Persistent IPに対応していない
2. Network Interface Configurationは0x06固定 (DHCP only)
3. LEDは1つのみ


Ver1.00 MEGA2560を基に起動する最小セットを作る
Ver1.01 LEDをMEGA2560と同じ4つに戻してみる
Ver1.02 PersistentIP Adressを入れてみる
Ver1.03 1,01に戻しUSer Define Name（Read Only）を入れてみる
Ver1.04 DISCOVERY_BUFFを削除してみる
Ver1.05 1.00に戻しUSer Define NameをReadWrite可能にする





