Released September 24, 2021 Device Version 1.02
The third stage of the set distributed by the lighting subcommittee of JIIA (Japan Industrial Imaging Association)

JIIA is Japan Industrial Imaging Comitte.
http://jiia.org/


The target device is
1．Arduino MEGA 2560 + Arduino Ethernet Shield 2 (W5500)
2．Arduino MEGA 2560 + Arduino Ethernet Shield   (W5100)

The second combination is cheap but currently doesn't work with LLA and
For advanced users as there is no guarantee that it will work even if the library is remade in the future

Arduino standard Ethernet Library does not support LLA.
If you want to connect by Peer to Peer, set the NIC to 192.168.xxx.xxx (Class C) and use it.
169.254.xxx.xxx may not be recognized by the standard W5100 or W5500 driver.
In that case, comment out all the LLA description in the Arduino source code and Forcibly set it to Persistent IP.

Device Version 1.02 Update information
1. Move Discovery_Buff etc. to Flash memory => Secure a large amount of work memory
   RAM usage 2064Byte (25%)-> 1776Byte (21%)




--------- Japanese --------------

2021年09月28日リリース Device Version 1.02
JIIA (一般社団法人日本インダストリアルイメージング協会) の照明分科会にて配布するセット 第3段目

ターゲットデバイスは
1．Arduino MEGA 2560 + Arduino Ethernet Shield 2 (W5500)
2．Arduino MEGA 2560 + Arduino Ethernet Shield   (W5100)


2番目の組み合わせは安いが現状LLAで動作しないし、
将来的にライブラリを作り変えても動く保証がないため上級者向け


Arduino標準のEthernet LibraryがLLAに対応していません。
Peer to Peerで接続したい場合はNICを192.168.xxx.xxx(Class C)に設定して使ってください。
169.254.xxx.xxxではW5100やW5500の標準ドライバが認識しない場合があります。
その場合はArduinoのソースコードでLLAの記述をすべてコメントアウトし、
強制的にPersistent IPになるように設定してください。


Device Version 1.02更新情報
1. Discovery BuffなどをFlashメモリに移動 => 大幅にワークメモリを確保
   RAM使用量 2064Byte (25%) -> 1776Byte (21%)

